/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KiemTraLan1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.StringTokenizer;
import java.util.TreeMap;

/**
 *
 * @author pc
 */
public class UDP_802 {
    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket();
            
            String mess1 = ";B18DCCN411;802";
            DatagramPacket sendPacket1 = new DatagramPacket(mess1.getBytes(), mess1.length(), InetAddress.getByName("203.162.10.109"), 2207);
            socket.send(sendPacket1);
            
            byte[] receivedData = new byte[65536];
            DatagramPacket receivePacket = new DatagramPacket(receivedData, receivedData.length);
            socket.receive(receivePacket);
            
            String data = new String(receivePacket.getData()).trim();
            System.out.println(data);
            
            String[] split = data.split(";");
            int n = Integer.parseInt(split[1]);
            
            StringBuilder builder = new StringBuilder(split[0]);
            StringTokenizer st = new StringTokenizer(split[2], ",");
            TreeMap<Integer, Integer> map = new TreeMap<>();
            
            while(st.hasMoreTokens()){
                String tmp = st.nextToken();
                int number = Integer.parseInt(tmp);
                if(map.containsKey(number)){
                    map.put(number, map.get(number) + 1);
                } else{
                    map.put(number, 1);
                }
            }
            
            builder.append(";");
            for(int i = 1; i <= n; i++){
                if(!map.containsKey(i)){
                    builder.append(Integer.toString(i)).append(",");
                }
            }
            
            builder.deleteCharAt(builder.length() - 1);
            String res = builder.toString();
            DatagramPacket sendPacket2 = new DatagramPacket(res.getBytes(), res.length(), InetAddress.getByName("203.162.10.109"), 2207);
            socket.send(sendPacket2);
            
            socket.close();
        } catch (SocketException ex) {
            ex.printStackTrace();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }   
    }
}
