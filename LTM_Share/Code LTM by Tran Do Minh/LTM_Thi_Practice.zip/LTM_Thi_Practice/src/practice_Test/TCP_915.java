/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 *
 * @author pc
 */
public class TCP_915 {
    public static String discardNumberAndDuplicate(String s){
        Map<Character,Integer> char_map = new LinkedHashMap<>();
        for(int i = 0; i < s.length(); i++){
            char c = s.charAt(i);
            if(Character.isAlphabetic(c)){
                char_map.put(c, 1);
            }
        }
        
        String res = "";
        for(Character c : char_map.keySet()){
            res += c;
        }
        return res;
    }
    
    public static void main(String[] args) throws IOException {
        String host = "203.162.10.109";
        int port = 2208;
        String maSV = "B18DCAT196;915";
        
        Socket socket = new Socket(host, port);
        BufferedWriter output = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        
        // gui masv len server
        output.write(maSV);
        output.newLine();
        output.flush();
        
        // nhan du lieu tu server
        String fromServer = input.readLine();
        
        // xu ly du lieu
        String res = "";
        res = discardNumberAndDuplicate(fromServer);
        
        // gui du lieu da xu ly len server
        output.write(res);
        output.newLine();
        output.flush();
        
        socket.close();
        
    }
}
