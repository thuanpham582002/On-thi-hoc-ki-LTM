/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class UDP_934 {
    public static String caesar(String mess, int offset){
        StringBuilder res = new StringBuilder();
        for(int i = 0; i < mess.length(); i++){
            if(mess.charAt(i) != ' '){
                int originalAlphabetPos = mess.charAt(i) - 'a';
                int newAlphabetPos = (originalAlphabetPos + offset) % 26;
                char newCharacter = (char) ('a' + newAlphabetPos);
                res.append(Character.toString(newCharacter));
            } else{
                res.append(Character.toString(mess.charAt(i)));
            }
        }
        return res.toString();
    }
    
    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket();
            
            String sendMes = ";B18DCCN411;934";
            DatagramPacket dp1 = new DatagramPacket(sendMes.getBytes(), sendMes.length(), InetAddress.getByName("localhost"), 1107);
            socket.send(dp1);
            
            byte[] receivedData = new byte[65536];
            DatagramPacket dp2 = new DatagramPacket(receivedData, receivedData.length);
            socket.receive(dp2);
            
            String deBai = new String(dp2.getData()).trim();
            System.out.println(deBai);
            String[] split = deBai.split(";");
            StringBuilder builder = new StringBuilder(split[0]);
            builder.append(";");
            
            String encode = split[1];
            int s = Integer.parseInt(split[2]);
            builder.append(caesar(encode, 26 - (s % 26)));
            
            String res = builder.toString();
            System.out.println(res);
            DatagramPacket dp3 = new DatagramPacket(res.getBytes(), res.length(), InetAddress.getByName("localhost"), 1107);
            socket.send(dp3);
            
            socket.close();
        } catch (SocketException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
