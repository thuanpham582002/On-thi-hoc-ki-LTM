/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class Server_701_Alternative {

    ServerSocket serverSocket = null;

    public Server_701_Alternative() {
    }

    public void createAndListenSocket() {
        try {
            serverSocket = new ServerSocket(2206);

            while (true) {
                Socket socket = serverSocket.accept();
                
                BufferedOutputStream bos = new BufferedOutputStream(socket.getOutputStream());
                BufferedInputStream bis = new BufferedInputStream(socket.getInputStream());
                
                byte[] receivedData = new byte[65536];
                bis.read(receivedData);
                String student = new String(receivedData).trim();
                System.out.println(student);
                
                String deBai = "1,3,9,19,33,20";
                bos.write(deBai.getBytes());
                bos.flush();
                
                // Can lam buoc nay de dam bao String constructor khong tao ra xau vuot qua chieu dai cua phan byte nhan duoc trong buffer
                int length = bis.read(receivedData);
                String res = new String(receivedData, 0, length).trim();
                System.out.println(res);
                
                String reply = "Chuc mung ban gui thanh cong";
                bos.write(reply.getBytes());
                bos.flush();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        Server_701_Alternative server = new Server_701_Alternative();
        server.createAndListenSocket();
    }
}
