/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author pc
 */
public class Test721 {

    public static void main(String[] args) {
        String deBai = "dgU0o ch2k22lds0o";
        System.out.println(deBai);

        LinkedHashMap<Character, Integer> hashMap = new LinkedHashMap<>();
        for (int i = 0; i < deBai.length(); i++) {
            if (deBai.charAt(i) != ' ') {
                if (hashMap.containsKey(deBai.charAt(i))) {
                    hashMap.put(deBai.charAt(i), hashMap.get(deBai.charAt(i)) + 1);
                } else {
                    hashMap.put(deBai.charAt(i), 1);
                }
            }
        }

        Set<Integer> set = new TreeSet<>();
        for (Map.Entry<Character, Integer> entry : hashMap.entrySet()) {
            int i = entry.getValue();
            set.add(i);
        }

        StringBuilder builder = new StringBuilder();
        for (Integer i : set) {
            if (i > 1) {
                for (Map.Entry<Character, Integer> entry : hashMap.entrySet()) {
                    char c = entry.getKey();
                    int num = entry.getValue();
                    if (num == i) {
                        builder.append(Character.toString(c)).append(":").append(Integer.toString(num)).append(",");
                    }
                }
            }
        }

        String res = builder.toString();
        System.out.println(res);
    }
}
