/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class UDP_801 {
    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket();
            
            String sendMes = ";B18DCCN411;801";
            DatagramPacket dp1 = new DatagramPacket(sendMes.getBytes(), sendMes.length(), InetAddress.getByName("203.162.10.109"), 2207);
            socket.send(dp1);
            
            byte[] receivedData = new byte[65536];
            DatagramPacket dp2 = new DatagramPacket(receivedData, receivedData.length);
            socket.receive(dp2);
            
            String deBai = new String(dp2.getData()).trim();
            System.out.println(deBai);
            
            String[] split = deBai.split(";");
            int n = Integer.parseInt(split[1]);
            
            StringBuilder builder = new StringBuilder(split[0]);
            StringTokenizer st = new StringTokenizer(split[2], ",");
            TreeMap<Integer,Integer> map = new TreeMap<>();
            
            while(st.hasMoreTokens()){
                String tmp = st.nextToken();
                int number = Integer.parseInt(tmp);
                if(!map.containsKey(number)){
                    map.put(number, 1);
                }
            }
            
            builder.append(";");
            for(int i = 1; i <= n; i++){
                if(!map.containsKey(i)){
                    builder.append(Integer.toString(i)).append(",");
                }
            }
            
            builder.deleteCharAt(builder.length() - 1);
            String res = builder.toString();
            System.out.println(res);
            
            DatagramPacket dp3 = new DatagramPacket(res.getBytes(), res.length(), InetAddress.getByName("203.162.10.109"), 2207);
            socket.send(dp3);
            
            socket.close();
        } catch (SocketException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
