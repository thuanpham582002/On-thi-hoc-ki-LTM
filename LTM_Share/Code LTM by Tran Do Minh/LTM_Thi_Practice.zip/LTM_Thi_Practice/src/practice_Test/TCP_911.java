/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class TCP_911 {
    
    public static int gcd(int a, int b){
        while(a != b){
            if(a > b){
                a = a - b;
            } else {
                b = b - a;
            }
        }
        return a;
    }
    
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("203.162.10.109", 2207);
            
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
            DataInputStream dis = new DataInputStream(socket.getInputStream());
            
            dos.writeUTF("B18DCCN411;911");
            
            int a = dis.readInt();
            int b = dis.readInt();
            
            int tong = a + b;
            int tich = a * b;
            int ucln = gcd(a, b);
            int bcnn = (a * b)/ucln;
            
            dos.writeInt(ucln);
            dos.writeInt(bcnn);
            dos.writeInt(tong);
            dos.writeInt(tich);
            
            dos.close();
            dis.close();
            socket.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
