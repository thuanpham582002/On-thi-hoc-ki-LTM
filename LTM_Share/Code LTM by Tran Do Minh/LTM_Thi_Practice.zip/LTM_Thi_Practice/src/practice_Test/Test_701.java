/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.StringTokenizer;

/**
 *
 * @author pc
 */
public class Test_701 {

    public static void main(String[] args) {
        String deBai = "1,3,9,19,33,20";
        StringTokenizer st = new StringTokenizer(deBai, ",");
        List<Integer> list = new ArrayList<>();
        while (st.hasMoreTokens()) {
            list.add(Integer.parseInt(st.nextToken()));
        }

        Collections.sort(list);
        int refVal = Integer.MAX_VALUE;
        for (int i = 0; i < list.size(); i++) {
            for (int j = i + 1; j < list.size(); j++) {
                refVal = Integer.min(Math.abs(list.get(j) - list.get(i)), refVal);
            }
        }

        int index1 = 0, index2 = 0;
        for (int i = 0; i < list.size(); i++) {
            for (int j = i + 1; j < list.size(); j++) {
                if (Math.abs(list.get(j) - list.get(i)) == refVal) {
                    index1 = list.get(i);
                    index2 = list.get(j);
                }
            }
        }

        StringBuilder builder = new StringBuilder();
        builder.append(Integer.toString(refVal)).append(",").append(Integer.toString(index1)).append(",").append(Integer.toString(index2));
        String res = builder.toString();
        System.out.println(res);
    }
}
