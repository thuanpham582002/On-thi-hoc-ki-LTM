/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class TCP_701 {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 2206);
            
            OutputStream os = new DataOutputStream(socket.getOutputStream());
            InputStream is = new DataInputStream(socket.getInputStream());
            
            String sendMes = "B18DCCN411;701";
            os.write(sendMes.getBytes());
            os.flush();
            
            byte[] receivedData = new byte[65536];
            is.read(receivedData);
            String deBai = new String(receivedData).trim();
            System.out.println(deBai);
            
            StringTokenizer st = new StringTokenizer(deBai, ",");
            List<Integer> list = new ArrayList<>();
            while(st.hasMoreTokens()){
                list.add(Integer.parseInt(st.nextToken()));
            }
            
            Collections.sort(list);
            int refVal = Integer.MAX_VALUE;
            for(int i = 0; i < list.size(); i++){
                for(int j = i + 1; j < list.size(); j++){
                    refVal = Integer.min(Math.abs(list.get(j) - list.get(i)), refVal);
                }
            }
            
            int index1 = 0, index2 = 0;
            for(int i = 0; i < list.size(); i++){
                for(int j = i + 1; j < list.size(); j++){
                    if(Math.abs(list.get(j) - list.get(i)) == refVal){
                        index1 = list.get(i);
                        index2 = list.get(j);
                    }
                }
            }
            
            StringBuilder builder = new StringBuilder();
            builder.append(Integer.toString(refVal)).append(",").append(Integer.toString(index1)).append(",").append(Integer.toString(index2));
            String res = builder.toString();
            System.out.println(res);
            
            os.write(res.getBytes());
            os.flush();
            
            // Can lam buoc nay de dam bao String constructor khong tao ra xau vuot qua chieu dai cua phan byte nhan duoc trong buffer
            int length = is.read(receivedData);
            String reply = new String(receivedData, 0, length).trim();
            System.out.println(reply);
            
            os.close();
            is.close();
            socket.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
