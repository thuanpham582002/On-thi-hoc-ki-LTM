/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class TCP_721 {

    public static void main(String[] args) {
        try {
            Socket socket = new Socket("203.162.10.109", 2208);

            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            String mesSend = "B18DCCN411;721";
            bw.write(mesSend);
            bw.newLine();
            bw.flush();

            String deBai = br.readLine();
            System.out.println(deBai);

            LinkedHashMap<Character, Integer> hashMap = new LinkedHashMap<>();
            for (int i = 0; i < deBai.length(); i++) {
                if (deBai.charAt(i) != ' ') {
                    if (hashMap.containsKey(deBai.charAt(i))) {
                        hashMap.put(deBai.charAt(i), hashMap.get(deBai.charAt(i)) + 1);
                    } else {
                        hashMap.put(deBai.charAt(i), 1);
                    }
                }
            }

            Set<Integer> set = new TreeSet<>();
            for (Map.Entry<Character, Integer> entry : hashMap.entrySet()) {
                int i = entry.getValue();
                set.add(i);
            }

            StringBuilder builder = new StringBuilder();
            for (Integer i : set) {
                if (i > 1) {
                    for (Map.Entry<Character, Integer> entry : hashMap.entrySet()) {
                        char c = entry.getKey();
                        int num = entry.getValue();
                        if (num == i) {
                            builder.append(Character.toString(c)).append(":").append(Integer.toString(num)).append(",");
                        }
                    }
                }
            }

            String res = builder.toString();
            System.out.println(res);

            bw.write(res);
            bw.newLine();
            bw.flush();

            br.close();
            bw.close();
            socket.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }
}
