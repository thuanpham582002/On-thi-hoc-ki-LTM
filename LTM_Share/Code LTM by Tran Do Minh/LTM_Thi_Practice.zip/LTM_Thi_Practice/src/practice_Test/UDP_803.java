/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class UDP_803 {

    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket();

            String sendMes = ";B18DCCN411;803";
            DatagramPacket dp1 = new DatagramPacket(sendMes.getBytes(), sendMes.length(), InetAddress.getByName("203.162.10.109"), 2208);
            socket.send(dp1);

            byte[] receivedData = new byte[65536];
            DatagramPacket dp2 = new DatagramPacket(receivedData, receivedData.length);
            socket.receive(dp2);

            String deBai = new String(dp2.getData()).trim();
            System.out.println(deBai);
            String[] split = deBai.split(";");

            StringBuilder builder = new StringBuilder(split[0]);
            builder.append(";");
            String data = split[1];

            LinkedHashMap<Character, Integer> hashMap = new LinkedHashMap<>();
            int maxValue = 0;
            for (int i = 0; i < data.length(); i++) {
                if (hashMap.containsKey(data.charAt(i))) {
                    hashMap.put(data.charAt(i), hashMap.get(data.charAt(i)) + 1);
                } else {
                    hashMap.put(data.charAt(i), 1);
                }
                if (maxValue < hashMap.get(data.charAt(i))) {
                    maxValue = hashMap.get(data.charAt(i));
                }
            }
            
            char c = 0;
            for(Map.Entry<Character, Integer> entry: hashMap.entrySet()){
                if(entry.getValue() == maxValue){
                    c = entry.getKey();
                    break;
                }
            }
            builder.append(Character.toString(c)).append(":");
            for (int i = 0; i < data.length(); i++){
                if(data.charAt(i) == c){
                    builder.append(Integer.toString(i + 1)).append(",");
                }
            }
            
            String res = builder.toString();
            System.out.println(res);
            
            DatagramPacket dp3 = new DatagramPacket(res.getBytes(), res.length(), InetAddress.getByName("203.162.10.109"), 2208);
            socket.send(dp3);
            
            socket.close();
        } catch (SocketException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
