/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class TCP_701_Alternative {

    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 2206);

            BufferedOutputStream bos = new BufferedOutputStream(socket.getOutputStream());
            BufferedInputStream bis = new BufferedInputStream(socket.getInputStream());
            
            String sendMes = "B18DCCN411;701";
            bos.write(sendMes.getBytes());
            bos.flush();
            
            byte[] receivedData = new byte[65536];
            bis.read(receivedData);
            String deBai = new String(receivedData).trim();

            System.out.println(deBai);
            StringTokenizer st = new StringTokenizer(deBai, ",");
            List<Integer> list = new ArrayList<>();
            while (st.hasMoreTokens()) {
                list.add(Integer.parseInt(st.nextToken()));
            }
            
            Collections.sort(list);
            int refVal = Integer.MAX_VALUE;
            for (int i = 0; i < list.size(); i++) {
                for (int j = i + 1; j < list.size(); j++) {
                    refVal = Integer.min(Math.abs(list.get(j) - list.get(i)), refVal);
                }
            }
            
            int index1 = 0, index2 = 0;
            for (int i = 0; i < list.size(); i++) {
                for (int j = i + 1; j < list.size(); j++) {
                    if (Math.abs(list.get(j) - list.get(i)) == refVal) {
                        index1 = list.get(i);
                        index2 = list.get(j);
                    }
                }
            }
            
            StringBuilder builder = new StringBuilder();
            builder.append(Integer.toString(refVal)).append(",").append(Integer.toString(index1)).append(",").append(Integer.toString(index2));
            String res = builder.toString();
            System.out.println(res);
            
            bos.write(res.getBytes());
            bos.flush();
            
            // Can lam buoc nay de dam bao String constructor khong tao ra xau vuot qua chieu dai cua phan byte nhan duoc trong buffer
            int length = bis.read(receivedData);
            String reply = new String(receivedData, 0, length).trim();
            System.out.println(reply);
            
            bos.close();
            bis.close();
            socket.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
