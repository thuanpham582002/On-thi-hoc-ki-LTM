/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class TCP_916 {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 2208);
            
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            
            String mesSend = "B18DCCN411;916";
            
            bw.write(mesSend);
            bw.newLine();
            bw.flush();
            
            String s1 = br.readLine();
            String s2 = br.readLine();
            System.out.println(s1);
            System.out.println(s2);
            StringBuilder builder = new StringBuilder();
            TreeMap<Character,Integer> map = new TreeMap<>();
            
            for(int i = 0; i < s2.length(); i++){
                if(!map.containsKey(s2.charAt(i))){
                    map.put(s2.charAt(i), 1);
                }
            }
            for(int i = 0; i < s1.length(); i++){
                if(!map.containsKey(s1.charAt(i))){
                    builder.append(s1.charAt(i));
                }
            }
            
            String res = builder.toString();
            System.out.println(res);
            
            bw.write(res);
            bw.newLine();
            bw.flush();
            
            bw.close();
            br.close();
            socket.close();
        } catch (IOException ex) {
            Logger.getLogger(TCP_916.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
