/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 *
 * @author pc
 */
public class TCP_912 {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("203.162.10.109", 2208);
            
            // Khoi tao BR va BW
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            
            // Gui 1 String len BW
            bw.write("B18DCCN411;912");
            bw.newLine();
            bw.flush();
            
            // Doc 1 String tu BR
            String deBai = br.readLine();
            System.out.println(deBai);
            StringBuilder s1 = new StringBuilder();
            StringBuilder s2 = new StringBuilder();
            String regex = "[a-zA-Z0-9]";
            
            for(int i = 0; i < deBai.length(); i++){
                if(Pattern.matches(regex, Character.toString(deBai.charAt(i)))){
                    s1.append(deBai.charAt(i));
                } else {
                    s2.append(deBai.charAt(i));
                }
            }
            
            System.out.println(s1.toString());
            System.out.println(s2.toString());
            
            bw.write(s1.toString());
            bw.newLine();
            bw.flush();
            
            bw.write(s2.toString());
            bw.newLine();
            bw.flush();
            
            // Dong socket
            br.close();
            bw.close();
            socket.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
