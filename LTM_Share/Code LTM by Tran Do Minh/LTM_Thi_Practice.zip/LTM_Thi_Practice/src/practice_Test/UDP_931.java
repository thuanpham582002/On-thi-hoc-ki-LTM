/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class UDP_931 {
    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket();
            
            String sendMes = ";B18DCCN411;931";
            DatagramPacket dp1 = new DatagramPacket(sendMes.getBytes(), sendMes.length(), InetAddress.getByName("10.170.4x.202"), 1107);
            socket.send(dp1);
            
            byte[] receivedData = new byte[65536];
            DatagramPacket dp2 = new DatagramPacket(receivedData, receivedData.length);
            socket.receive(dp2);
            
            String deBai = new String(dp2.getData()).trim();
            System.out.println(deBai);
            
            String[] split = deBai.split(";");
            StringBuilder builder = new StringBuilder(split[0]);
            StringTokenizer st = new StringTokenizer(split[1], ",");
            
            List<Integer> list = new ArrayList<>();
            while(st.hasMoreTokens()){
                String tmp = st.nextToken();
                int number = Integer.parseInt(tmp);
                list.add(number);
            }
            
            Collections.sort(list);
            builder.append(";").append(Integer.toString(list.get(list.size() - 1))).append(",").append(Integer.toString(list.get(0)));
            String res = builder.toString();
            System.out.println(res);
            
            DatagramPacket dp3 = new DatagramPacket(res.getBytes(), res.length(), InetAddress.getByName("10.170.4x.202"), 1107);
            socket.send(dp3);
            
            socket.close();
        } catch (SocketException ex) {
            ex.printStackTrace();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
