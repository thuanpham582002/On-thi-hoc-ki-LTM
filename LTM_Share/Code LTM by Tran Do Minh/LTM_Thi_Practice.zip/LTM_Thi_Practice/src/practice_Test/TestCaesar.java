/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

/**
 *
 * @author pc
 */
public class TestCaesar {

    public static String caesar(String mess, int offset) {
        StringBuilder res = new StringBuilder();
        for (int i = 0; i < mess.length(); i++) {
            if (mess.charAt(i) != ' ') {
                int originalAlphabetPos = mess.charAt(i) - 'a';
                int newAlphabetPos = (originalAlphabetPos + offset) % 26;
                char newCharacter = (char) ('a' + newAlphabetPos);
                res.append(Character.toString(newCharacter));
            } else{
                res.append(Character.toString(mess.charAt(i)));
            }
        }
        return res.toString();
    }

    public static void main(String[] args) {
        String deBai = "requestId;ro dyvn wo s myevn xofob dokmr k vvkwk dy nbsfo;10";
        System.out.println(deBai);
        String[] split = deBai.split(";");
        StringBuilder builder = new StringBuilder(split[0]);
        builder.append(";");

        String encode = split[1];
        int s = Integer.parseInt(split[2]);
        builder.append(caesar(encode, 26 - (s % 26)));

        String res = builder.toString();
        System.out.println(res);
    }
}
