/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class UDP_932 {
    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket();
            
            String sendMes = ";B18DCCN411;932";
            DatagramPacket dp1 = new DatagramPacket(sendMes.getBytes(), sendMes.length(), InetAddress.getByName("203.162.10.109"), 2208);
            socket.send(dp1);
            
            byte[] receivedData = new byte[65536];
            DatagramPacket dp2 = new DatagramPacket(receivedData, receivedData.length);
            socket.receive(dp2);
            
            String deBai = new String(dp2.getData()).trim();
            System.out.println(deBai);
            String[] split = deBai.split(";");

            StringTokenizer st = new StringTokenizer(split[1]);
            StringBuilder builder = new StringBuilder(split[0]);
            
            builder.append(";");
            while(st.hasMoreTokens()){
                String word = st.nextToken();
                StringBuilder tmp = new StringBuilder();
                tmp.append(Character.toUpperCase(word.charAt(0)));
                for(int i = 1; i < word.length(); i++){
                    tmp.append(Character.toLowerCase(word.charAt(i)));
                }
                tmp.append(" ");
                builder.append(tmp.toString());
            }
            
            builder.deleteCharAt(builder.length() - 1);
            String res = builder.toString();
            System.out.println(res);
            
            DatagramPacket dp3 = new DatagramPacket(res.getBytes(), res.length(), InetAddress.getByName("203.162.10.109"), 2208);
            socket.send(dp3);
            
            socket.close();
        } catch (SocketException ex) {
            ex.printStackTrace();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
    }
}
