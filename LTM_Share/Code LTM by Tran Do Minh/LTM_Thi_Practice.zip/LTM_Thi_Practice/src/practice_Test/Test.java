/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.regex.Pattern;

/**
 *
 * @author pc
 */
public class Test {

    public static void main(String[] args) {
        // requestId;Qnc8d5x78aldSGWWmaAAjyg3
        String deBai = "requestId;23t7AB8WaaysdWSNCAa8a29232";
        String[] split = deBai.split(";");

        StringBuilder builder = new StringBuilder(split[0]);
        builder.append(";");
        String data = split[1];

        LinkedHashMap<Character, Integer> hashMap = new LinkedHashMap<>();
        int maxValue = 0;
        for (int i = 0; i < data.length(); i++) {
            if (hashMap.containsKey(data.charAt(i))) {
                hashMap.put(data.charAt(i), hashMap.get(data.charAt(i)) + 1);
            } else {
                hashMap.put(data.charAt(i), 1);
            }
            if (maxValue < hashMap.get(data.charAt(i))) {
                maxValue = hashMap.get(data.charAt(i));
            }
        }

        char c = 0;
        for (Map.Entry<Character, Integer> entry : hashMap.entrySet()) {
            if (entry.getValue() == maxValue) {
                c = entry.getKey();
                break;
            }
        }
        builder.append(Character.toString(c)).append(":");
        for (int i = 0; i < data.length(); i++) {
            if (data.charAt(i) == c) {
                builder.append(Integer.toString(i + 1)).append(",");
            }
        }

        String res = builder.toString();
        System.out.println(res);
    }
}
