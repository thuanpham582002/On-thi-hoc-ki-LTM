/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice_Test;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class UDP_936 {
    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket();
            
            String sendMes = ";B18DCCN411;936";
            DatagramPacket dp1 = new DatagramPacket(sendMes.getBytes(), sendMes.length(), InetAddress.getByName("localhost"), 1108);
            socket.send(dp1);
            
            byte[] receivedData = new byte[65536];
            DatagramPacket dp2 = new DatagramPacket(receivedData, receivedData.length);
            socket.receive(dp2);
            
            String debai = new String(dp2.getData()).trim();
            String[] split = debai.split(";");
            
            StringBuilder builder = new StringBuilder(split[0]);
            builder.append(";");
            String s1 = split[1];
            String s2 = split[2];
            TreeMap<Character,Integer> map = new TreeMap<>();
            
            for(int i = 0; i < s2.length(); i++){
                if(!map.containsKey(s2.charAt(i))){
                    map.put(s2.charAt(i), 1);
                }
            }
            for(int i = 0; i < s1.length(); i++){
                if(!map.containsKey(s1.charAt(i))){
                    builder.append(s1.charAt(i));
                }
            }
            
            String res = builder.toString();
            System.out.println(res);
            
            DatagramPacket dp3 = new DatagramPacket(res.getBytes(), res.length(), InetAddress.getByName("localhost"), 1108);
            socket.send(dp3);
            
            socket.close();
        } catch (SocketException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
