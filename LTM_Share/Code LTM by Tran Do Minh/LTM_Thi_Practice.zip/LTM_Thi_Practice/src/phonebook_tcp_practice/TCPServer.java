/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonebook_tcp_practice;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class TCPServer {
    ServerSocket serverSocket = null;

    public TCPServer() {
    }
    
    public void createAndListenSocket(){
        try {
            // Tao serverSocket o cong 4400 & registryImpl
            serverSocket = new ServerSocket(4400);
            RegistryImpl registryImpl = new RegistryImpl();
            
            while(true){ // Luon doi
                // Tao socket accept ket noi o cong 4400
                Socket socket = serverSocket.accept();
                
                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                
                // Nhan Object cho biet lua chon & ep kieu
                String choice = (String) ois.readObject();
                String reply;
                System.out.println(choice);
                
                
                // Nhan Object tu client cho tung truong hop & ep kieu
                // Thuc thi & gui object cho biet phan hoi
                if(!choice.equals("3")){
                    if(choice.equals("1")){ // TH1
                        Person p = (Person) ois.readObject();
                        registryImpl.add(p);
                        reply = "Them thanh cong";
                    } else{ // TH2
                        String nameReq = (String) ois.readObject();
                        System.out.println(nameReq);
                        String number = registryImpl.getPhone(nameReq);
                        if(number.equals("")){
                            reply = "Nguoi nay khong co trong danh ba!";
                        } else{
                            reply = number;
                        }
                    }
                    
                    // Gui ket qua
                    oos.writeObject(reply);
                } else{ // TH3
                    // Chuyen Iterable thanh List
                    Iterable<Person> source = registryImpl.getAll();
                    List<Person> contacList = new ArrayList<>();
                    source.forEach(contacList::add);
                    
                    // Gui ket qua
                    oos.writeObject(contacList);
                }
                
                
                // Gui xong flush OOS
                oos.flush();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        TCPServer server = new TCPServer();
        server.createAndListenSocket();
    }
}
