/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonebook_tcp_practice;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class TCPClient {
    Socket socket = null;

    public TCPClient() {
    }
    
    public void createAndListenSocket(){
        try {
            socket = new Socket("localhost", 4400);
            System.out.println(socket);
            
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            
            System.out.println("DANH BA DIEN THOAI SU DUNG TCP SOCKET");
            System.out.println("Vui long chon 1 trong 3 lua chon sau:");
            System.out.println("1. Them 1 nguoi cung so dien thoai vao danh ba");
            System.out.println("2. Tim kiem so dien thoai cua 1 nguoi trong danh ba");
            System.out.println("3. Xem toan bo danh ba");
            
            Scanner in = new Scanner(System.in);
            String choice = in.nextLine();
            
            while(!choice.equals("1") && !choice.equals("2") && !choice.equals("3")){
                System.out.println("Vui long nhap lai lua chon!");
                choice = in.nextLine();
            }
            
            // Gui Object cho biet lua chon
            // Moi lan gui phai flush OOS
            oos.writeObject(choice);
            oos.flush();
            
            // Gui Object chua du lieu
            switch(choice){
                case("1"): // TH1
                    System.out.println("Nhap ten nguoi:");
                    String name = in.nextLine();
                    System.out.println("Nhap so dien thoai:");
                    String number = in.nextLine();
                    Person p = new Person(name, number);
                    oos.writeObject(p);
                    break;
                case("2"): // TH2
                    System.out.println("Nhap ten nguoi can tim:");
                    String nameReq = in.nextLine();
                    oos.writeObject(nameReq);
                    break;
                // TH3 ko can gui
            }
            
            oos.flush();
            
            // Nhan Object chua du lieu tu server & ep kieu, in ket qua
            switch(choice){
                case("3"): // TH3
                    try {
                        List<Person> contactList = (ArrayList<Person>) ois.readObject();
                        for(Person p: contactList){
                            System.out.println(p);
                        }
                    } catch (ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
                    break;
                default:
                    try {
                        String reply = (String) ois.readObject();
                        System.out.println(reply);
                    } catch (ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
                    break;
            }
            
            // Dong socket
            socket.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }        
    }
    
    public static void main(String[] args) {
        TCPClient client = new TCPClient();
        client.createAndListenSocket();
    }
}
