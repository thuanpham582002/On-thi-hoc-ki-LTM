/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TCP;

/**
 *
 * @author pc
 */
public class Test {

    public static void main(String[] args) {
        Customer918 cus = new Customer918(1, "Hello", "ngUyEn   VaN   hAI   DuONg", "10-11-2012");

        String name = cus.getName();
        name = name.replaceAll("\\s+", " ");
        String dOb = cus.getDayOfBirdth();

        String[] split = name.split(" ");
        String lastName = split[split.length - 1];
        StringBuilder nameBuilder = new StringBuilder();
        StringBuilder userNameBuilder = new StringBuilder();
        for (int i = 0; i < lastName.length(); i++) {
            nameBuilder.append(Character.toTitleCase(lastName.charAt(i)));
        }
        nameBuilder.append(", ");
        for (int i = 0; i < split.length - 1; i++) {
            String tmp = split[i];

            nameBuilder.append(Character.toUpperCase(tmp.charAt(0)));
            userNameBuilder.append(Character.toLowerCase(tmp.charAt(0)));

            for (int j = 1; j < tmp.length(); j++) {
                nameBuilder.append(Character.toLowerCase(tmp.charAt(j)));
            }
            nameBuilder.append(" ");
        }
        for (int i = 0; i < lastName.length(); i++) {
            userNameBuilder.append(Character.toLowerCase(lastName.charAt(i)));
        }
        nameBuilder.deleteCharAt(nameBuilder.length() - 1);
        cus.setName(nameBuilder.toString());
        cus.setUserName(userNameBuilder.toString());

        String[] split1 = dOb.split("-");
        StringBuilder dObBuilder = new StringBuilder();
        dObBuilder.append(split1[1]).append("/").append(split1[0]).append("/").append(split1[2]);
        cus.setDayOfBirdth(dObBuilder.toString());

        System.out.println(cus);
    }
}
