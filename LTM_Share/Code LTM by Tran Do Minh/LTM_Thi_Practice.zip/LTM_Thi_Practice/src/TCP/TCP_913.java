/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TCP;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 *
 * @author pc
 */
public class TCP_913 {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("203.162.10.109", 2209);
            
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            
            String sendMes = "B18DCCN411;913";
            oos.writeObject(sendMes);
            oos.flush();
            
            Student student = (Student) ois.readObject();
            float gpa = student.getGpa();
            System.out.println(gpa);
            
            if(gpa > 3.7 && gpa <= 4)
                student.setGpaLetter("A");
            else if(gpa > 3.0 && gpa <= 3.7)
                student.setGpaLetter("B");
            else if(gpa > 2.0 && gpa <= 3.0)
                student.setGpaLetter("C");
            else if(gpa > 1.0 && gpa <= 2.0)
                student.setGpaLetter("D");
            else
                student.setGpaLetter("F");
            
            oos.writeObject(student);
            socket.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }
}
