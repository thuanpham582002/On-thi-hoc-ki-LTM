/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UDP;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class Server_933 {

    DatagramSocket socket = null;

    public Server_933() {
    }

    public void createAndListenSocket() {
        try {
            socket = new DatagramSocket(2209);

            while (true) {
                // Nhan Object lan 1
                byte[] data = new byte[65536];
                DatagramPacket dp1 = new DatagramPacket(data, data.length);
                socket.receive(dp1);
                byte[] receivedData = dp1.getData();
                ByteArrayInputStream bais = new ByteArrayInputStream(receivedData);
                ObjectInputStream ois = new ObjectInputStream(bais);

                Student933 student933 = (Student933) ois.readObject();
                System.out.println(student933);

                student933.setId("111");
                student933.setName(" hA   tHi  HonG   ngAn ");
                
                // Gui lai Object
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ObjectOutputStream oos = new ObjectOutputStream(baos);
                oos.writeObject(student933);
                byte[] sendData = baos.toByteArray();
                DatagramPacket dp2 = new DatagramPacket(sendData, sendData.length, dp1.getAddress(), dp1.getPort());
                socket.send(dp2);
                oos.flush();
                
                // Nhan Object lan 2 - Dung lai packet cua lan nhan 1
                socket.receive(dp1);
                byte[] receivedData2 = dp1.getData();
                Student933 s = (Student933) ois.readObject();
                System.out.println(s);
            }
        } catch (SocketException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Server_933 server = new Server_933();
        server.createAndListenSocket();
    }
}
