/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UDP;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class UDP_933 {
    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket();
            
            // Gui Object
            Student933 stu = new Student933("B18DCCN411");
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(stu);
            
            byte[] sendData1 = baos.toByteArray();
            DatagramPacket dp1 = new DatagramPacket(sendData1, sendData1.length, InetAddress.getByName("localhost"), 2209);
            socket.send(dp1);
            oos.flush();
            
            // Nhan Object
            byte[] receivedData = new byte[65536];
            DatagramPacket dp2 = new DatagramPacket(receivedData, receivedData.length);
            socket.receive(dp2);
            byte[] data = dp2.getData();
            ByteArrayInputStream bais = new ByteArrayInputStream(data);
            ObjectInputStream ois = new ObjectInputStream(bais);
            
            Student933 student = (Student933) ois.readObject();
            System.out.println(student);
            String name = student.getName();
            
            StringBuilder nameBuilder = new StringBuilder();
            StringBuilder emailBuilder = new StringBuilder();
            StringTokenizer st = new StringTokenizer(name);
            
            int cnt = st.countTokens();
            int num = 0;
            while(st.hasMoreTokens()){
                String word = st.nextToken();
                StringBuilder tmp = new StringBuilder();
                tmp.append(Character.toUpperCase(word.charAt(0)));
                for(int i = 1; i < word.length(); i++){
                    tmp.append(Character.toLowerCase(word.charAt(i)));
                }
                tmp.append(" ");
                nameBuilder.append(tmp.toString());
                
                num++;
                if(num != cnt){
                    emailBuilder.append(Character.toLowerCase(word.charAt(0)));
                } else {
                    tmp.deleteCharAt(tmp.length() - 1);
                    tmp.replace(0, 1, Character.toString(Character.toLowerCase(tmp.charAt(0))));
                    emailBuilder.insert(0, tmp.toString());
                    emailBuilder.append("@ptit.edu.vn");
                }
            }
            
            nameBuilder.deleteCharAt(nameBuilder.length() - 1);
            student.setName(nameBuilder.toString());
            student.setEmail(emailBuilder.toString());
            System.out.println(student);
            
            // Gui Object
            oos.writeObject(student);
            byte[] sendData2 = baos.toByteArray();
            DatagramPacket dp3 = new DatagramPacket(sendData2, sendData2.length, InetAddress.getByName("localhost"), 2209);
            socket.send(dp3);
            
            socket.close();
        } catch (SocketException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }
}
