/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UDP;

import java.util.StringTokenizer;

/**
 *
 * @author pc
 */
public class Test {

    public static void main(String[] args) {
        Student933 student = new Student933("1", "B17DCCN411", "hA tHi HonG   nGAn");
        String name = student.getName();

        StringBuilder nameBuilder = new StringBuilder();
        StringBuilder emailBuilder = new StringBuilder();
        StringTokenizer st = new StringTokenizer(name);

        int cnt = st.countTokens();
        int num = 0;
        while (st.hasMoreTokens()) {
            String word = st.nextToken();
            StringBuilder tmp = new StringBuilder();
            tmp.append(Character.toUpperCase(word.charAt(0)));
            for (int i = 1; i < word.length(); i++) {
                tmp.append(Character.toLowerCase(word.charAt(i)));
            }
            tmp.append(" ");
            nameBuilder.append(tmp.toString());

            num++;
            if (num != cnt) {
                emailBuilder.append(Character.toLowerCase(word.charAt(0)));
            } else {
                tmp.deleteCharAt(tmp.length() - 1);
                tmp.replace(0, 1, Character.toString(Character.toLowerCase(tmp.charAt(0))));
                emailBuilder.insert(0, tmp.toString());
                emailBuilder.append("@ptit.edu.vn");
            }
        }

        nameBuilder.deleteCharAt(nameBuilder.length() - 1);

        System.out.println(nameBuilder.toString());
        System.out.println(emailBuilder.toString());
    }
}
