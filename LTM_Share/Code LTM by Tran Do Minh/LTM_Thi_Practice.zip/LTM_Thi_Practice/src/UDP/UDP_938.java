/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UDP;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class UDP_938 {
    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket();
            
            // Gui String
            String mesSend = "B18DCCN411;938";
            DatagramPacket dp1 = new DatagramPacket(mesSend.getBytes(), mesSend.length(), InetAddress.getByName("localhost"), 2209);
            socket.send(dp1);
            
            // Nhan Object
            byte[] receivedData = new byte[65536];
            DatagramPacket dp2 = new DatagramPacket(receivedData, receivedData.length);
            socket.receive(dp2);
            byte[] data = dp2.getData();
            ByteArrayInputStream bais = new ByteArrayInputStream(data);
            ObjectInputStream ois = new ObjectInputStream(bais);
            
            Customer938 cus = (Customer938) ois.readObject();
            System.out.println(cus);
            String name = cus.getName();
            name = name.replaceAll("\\s+", " "); // Loai bo 2 khoang trang lien tiep khi dung split - Dung StringTokenizer se khong bi
            String dOb = cus.getDayOfBirth();

            String[] split = name.split(" ");
            String lastName = split[split.length - 1];
            StringBuilder nameBuilder = new StringBuilder();
            StringBuilder userNameBuilder = new StringBuilder();
            for (int i = 0; i < lastName.length(); i++) {
                nameBuilder.append(Character.toUpperCase(lastName.charAt(i)));
            }
            nameBuilder.append(", ");
            for (int i = 0; i < split.length - 1; i++) {
                String tmp = split[i];

                nameBuilder.append(Character.toUpperCase(tmp.charAt(0)));
                userNameBuilder.append(Character.toLowerCase(tmp.charAt(0)));

                for (int j = 1; j < tmp.length(); j++) {
                    nameBuilder.append(Character.toLowerCase(tmp.charAt(j)));
                }
                nameBuilder.append(" ");
            }
            for (int i = 0; i < lastName.length(); i++) {
                userNameBuilder.append(Character.toLowerCase(lastName.charAt(i)));
            }
            nameBuilder.deleteCharAt(nameBuilder.length() - 1);
            cus.setName(nameBuilder.toString());
            cus.setUserName(userNameBuilder.toString());

            String[] split1 = dOb.split("-");
            StringBuilder dObBuilder = new StringBuilder();
            dObBuilder.append(split1[1]).append("/").append(split1[0]).append("/").append(split1[2]);
            cus.setDayOfBirth(dObBuilder.toString());

            System.out.println(cus);
            
            // Gui Object
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(cus);
            
            byte[] sendData = baos.toByteArray();
            DatagramPacket dp3 = new DatagramPacket(sendData, sendData.length, InetAddress.getByName("localhost"), 2209);
            socket.send(dp3);
            
            socket.close();
        } catch (SocketException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        
    }
}
