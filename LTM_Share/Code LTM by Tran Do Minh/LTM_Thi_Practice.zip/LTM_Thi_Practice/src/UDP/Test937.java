/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UDP;

/**
 *
 * @author pc
 */
public class Test937 {

    public static void main(String[] args) {
        Product937 product937 = new Product937();
        product937.setId("Id");
        product937.setCode("B18DCCN411");
        product937.setQuantity(1899);
        product937.setName("T520 thinkpad lenovo");
        
        System.out.println(product937);
        String name = product937.getName();
        String quan = Integer.toString(product937.getQuantity());

        String[] split = name.split(" ");
        StringBuilder builder1 = new StringBuilder();
        builder1.append(split[split.length - 1]).append(" ");
        for (int i = 1; i < split.length - 1; i++) {
            builder1.append(split[i]);
            builder1.append(" ");
        }
        builder1.append(split[0]);
        product937.setName(builder1.toString());

        StringBuilder builder2 = new StringBuilder();
        for (int i = quan.length() - 1; i >= 0; i--) {
            builder2.append(quan.charAt(i));
        }

        int quantity = Integer.parseInt(builder2.toString());
        product937.setQuantity(quantity);
        System.out.println(product937);
    }
}
