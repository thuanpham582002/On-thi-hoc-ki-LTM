/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonebook_udp_practice;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author pc
 */
public class RegistryImpl implements Registry_itf{
    List<Person> contactList = new ArrayList<>();
    
    @Override
    public void add(Person p) {
        contactList.add(p);
    }

    @Override
    public String getPhone(String name) {
        Person p = search(name);
        if(p != null){
            return p.getNumber();
        } else {
            return "";
        }
    }

    @Override
    public Iterable<Person> getAll() {
        return contactList;
    }

    @Override
    public Person search(String name) {
        for(Person p: contactList){
            if(p.getName().equals(name)){
                return p;
            }
        }
        return null;
    }
    
}
