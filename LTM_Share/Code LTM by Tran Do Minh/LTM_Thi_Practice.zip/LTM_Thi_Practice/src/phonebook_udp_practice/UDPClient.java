/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonebook_udp_practice;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class UDPClient {
    DatagramSocket socket = null;

    public UDPClient() {
    }
    
    public void createAndListenSocket(){
        try {
            // Tao DatagramSocket & mang byte chua du lieu nhan duoc tu server
            socket = new DatagramSocket();
            byte[] receivedData = new byte[65536];
            
            System.out.println("DANH BA SU DUNG UDP SOCKET");
            System.out.println("Vui long chon 1 trong 3 lua chon sau:");
            System.out.println("1. Them 1 nguoi vao danh ba");
            System.out.println("2. Tim kiem 1 nguoi trong danh ba");
            System.out.println("3. Xem toan bo danh ba");
            
            Scanner in = new Scanner(System.in);
            String choice = in.nextLine();
            
            while(!choice.equals("1") && !choice.equals("2") && !choice.equals("3")){
                System.out.println("Vui long nhap lai lua chon!");
                choice = in.nextLine();
            }
            
            // Gui goi tin (packet) - String cho biet yeu cau - String chuyen thanh chuoi byte
            // Packet gui co 4 tham so
            DatagramPacket dp1 = new DatagramPacket(choice.getBytes(), choice.length(), InetAddress.getByName("localhost"), 3300);
            socket.send(dp1);
            
            // Gui goi tin - chua du lieu gui len
            switch(choice){
                case("1"): // TH1
                    System.out.println("Nhap ten nguoi:");
                    String name = in.nextLine();
                    System.out.println("Nhap so dien thoai:");
                    String number = in.nextLine();
                    Person p = new Person(name, number);
                    
                    // Gui Object cho TH1 - OOS lay tu BAOS
                    // WriteObject len OOS - BAOS thanh byteArray - gui goi tin
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    ObjectOutputStream oos = new ObjectOutputStream(baos);
                    oos.writeObject(p);
                    byte[] sendData1 = baos.toByteArray();
                    
                    DatagramPacket dp2 = new DatagramPacket(sendData1, sendData1.length, InetAddress.getByName("localhost"), 3300);
                    socket.send(dp2);
                    break;
                case("2"): // TH2
                    System.out.println("Nhap ten nguoi");
                    String nameReq = in.nextLine();
                    
                    // Gui String cho TH2
                    DatagramPacket dp3 = new DatagramPacket(nameReq.getBytes(), nameReq.length(), InetAddress.getByName("localhost"), 3300);
                    socket.send(dp3);
                    break;
                // TH3 ko gui gi
            }
            
            // Nhan goi tin cho biet ket qua - Nhan goi tin vao mang receivedData
            // Packet nhan co 2 tham so
            // Sau do tao 1 mang byte getData tu goi tin nhan (vi mang byte nay nhieu kieu du lieu khac nhau: String / List)
            // BAIS lay tu mang byte sau - OIS lay du BAIS
            DatagramPacket dp4 = new DatagramPacket(receivedData, receivedData.length);
            socket.receive(dp4);
            byte[] data = dp4.getData();
            ByteArrayInputStream bais = new ByteArrayInputStream(data);
            ObjectInputStream ois = new ObjectInputStream(bais);
            
            // Nhan goi tin tu server - Nhan Object tu OIS & ep kieu
            // Ca 3 TH server deu gui ve object
            switch(choice){
                case("3"): // TH3
                    List<Person> contactList = (ArrayList<Person>) ois.readObject();
                    for(Person p: contactList){
                        System.out.println(p);
                    }
                    break; // TH1 & 2
                default:
                    String reply = (String) ois.readObject();
                    System.out.println(reply);
                    break;
            }
            
            socket.close();
        } catch (SocketException ex) {
            ex.printStackTrace();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        UDPClient client = new UDPClient();
        client.createAndListenSocket();
    }
}
