/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonebook_udp_practice;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc
 */
public class UDPServer {
    DatagramSocket socket = null;

    public UDPServer() {
    }
    
    public void createAndListenSocket(){
        try {
            // Tao socket o cong 3300 & registryImpl
            socket = new DatagramSocket(3300);
            RegistryImpl registryImpl = new RegistryImpl();
            
            while(true){ // Luon doi
                
                // Nhan packet cho biet lua chon - packet nhan vao mang byte - mang byte phai dat trong WHILE
                // Chuyen lua chon thanh String - new String(packet.getData)
                byte[] data = new byte[65536];
                DatagramPacket incomingPacket = new DatagramPacket(data, data.length);
                socket.receive(incomingPacket);
                String choice = new String(incomingPacket.getData()).trim();
                String reply;
                System.out.println(choice);
                
                // Nhan packet cho biet du lieu gui len - packet nhan vao mang byte khai bao tu truoc
                if(!choice.equals("3")){
                    socket.receive(incomingPacket);
                    
                    if(choice.equals("1")){  // TH1
                        // Nhan packet chua Object - packet nhan vao 1 mang byte moi
                        byte[] receivedData = incomingPacket.getData();
                        ByteArrayInputStream bais = new ByteArrayInputStream(receivedData);
                        ObjectInputStream ois = new ObjectInputStream(bais);
                        
                        // Nhan object tu OIS & ep kieu
                        Person p = (Person) ois.readObject();
                        registryImpl.add(p);
                        reply = "Them thanh cong!";
                    } else{ // TH2
                        // Nhan packet chua String & ep kieu thanh String
                        String nameReq = new String(incomingPacket.getData()).trim();
                        String number = registryImpl.getPhone(nameReq);
                        if(number.equals("")){
                            reply = "Nguoi nay khong co trong danh ba!";
                        } else{
                            reply = number;
                        }
                    }
                    
                    // TH1 & 2 deu gui lai Object (object la String)
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    ObjectOutputStream oos = new ObjectOutputStream(baos);
                    oos.writeObject(reply);
                    byte[] sendData1 = baos.toByteArray();
                    
                    DatagramPacket dp1 = new DatagramPacket(sendData1, sendData1.length, incomingPacket.getAddress(), incomingPacket.getPort());
                    socket.send(dp1);
                } else{ // TH3
                    // Chuyen Iterable thanh List
                    Iterable<Person> source = registryImpl.getAll();
                    List<Person> contactList = new ArrayList<>();
                    source.forEach(contactList::add);
                    
                    // TH3 cung gui lai Object
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    ObjectOutputStream oos = new ObjectOutputStream(baos);
                    oos.writeObject(contactList);
                    byte[] sendData2 = baos.toByteArray();
                    
                    DatagramPacket dp2 = new DatagramPacket(sendData2, sendData2.length, incomingPacket.getAddress(), incomingPacket.getPort());
                    socket.send(dp2);
                }
            }
        } catch (SocketException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        UDPServer server = new UDPServer();
        server.createAndListenSocket();
    }
}
